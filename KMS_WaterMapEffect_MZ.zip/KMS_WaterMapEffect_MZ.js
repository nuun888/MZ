/*:-----------------------------------------------------------------------------------
 * KMS_WaterMapEffect_MZ.js
 * -------------------------------------------------------------------------------------
 */
//=============================================================================
// KMS_WaterMapEffect_MZ.js
//  last update: 2026/06/04 (MZ Compatible Version)
//=============================================================================

/*
 * This plugin can be used in the environment which supports WebGL.
 */

/*:
 * @target MZ
 * @plugindesc [v1.1.0-MZ] Applies water effect to maps and battles.
 * @author TOMY (Kamesoft) / Ported to MZ
 * 
 * @param FlickerImage
 * @default KMS_cloud
 * @dir img/system/
 * @type file
 * @desc The image which is used for flicker effect.
 *
 * @param WaveImage
 * @default KMS_wave
 * @dir img/system/
 * @type file
 * @desc The image which is used for wave.
 *
 * @param WaveOpacity
 * @default 64
 * @type number
 * @min 0
 * @max 255
 * @desc Opacity for wave. Range is from 0 to 255.
 *
 * @param SpeedX
 * @default -1.0
 * @type number
 * @decimals 1
 * @desc The offset value for the X coordinate.
 * 
 * @param SpeedY
 * @default 0.5
 * @type number
 * @decimals 1
 * @desc The offset value for the Y coordinate.
 * 
 * @param AutoToneChange
 * @default 1
 * @type select
 * @option Disable
 * @value 0
 * @option Enable
 * @value 1
 * @desc Color filter is applied automatically.
 *
 * @help This plugin does not provide plugin commands.
 * Set <WaterEffect> in the map note to enable the effect.
 * 
 * This plugin has been modified by NUUN to work with RPG Maker MZ.
 */

/*:ja
 * @target MZ
 * @plugindesc [v1.1.0-MZ] マップや戦闘画面に水中風のエフェクトを適用します。
 * @author TOMY (Kamesoft) / MZ移植
 * 
 * @param FlickerImage
 * @default KMS_cloud
 * @dir img/system/
 * @type file
 * @desc 水の揺らぎを表現するための画像です。
 *
 * @param WaveImage
 * @default KMS_wave
 * @dir img/system/
 * @type file
 * @desc 水面の波を表現するための画像です。
 *
 * @param WaveOpacity
 * @default 64
 * @type number
 * @min 0
 * @max 255
 * @desc 波の不透明度です。0 ～ 255 で指定します。
 *
 * @param SpeedX
 * @default -1.0
 * @type string
 * @decimals 1
 * @desc 水の横方向への移動速度です。
 *
 * @param SpeedY
 * @default 0.5
 * @type string
 * @decimals 1
 * @desc 水の縦方向への移動速度です。
 * 
 * @param AutoToneChange
 * @default 1
 * @type select
 * @option オフ
 * @value 0
 * @option オン
 * @value 1
 * @desc 水中エフェクト時、画面の色調を自動的に変更します。
 *
 * @help このプラグインには、プラグインコマンドはありません。
 * 効果を適用したいマップのメモ欄に <WaterEffect> と記述してください。
 * 
 * 当プラグインはRPGツクールMZで動作するようにNUUNが改変しております。
 */

var Imported = Imported || {};
Imported.KMS_WaterMapEffect_MZ = true;

(() => {
    const pluginParams = PluginManager.parameters('KMS_WaterMapEffect_MZ') || PluginManager.parameters('KMS_WaterMapEffect');
    const Param = {};
    Param.imageDir  = 'img/system/';
    Param.dispImage = pluginParams['FlickerImage'] || 'KMS_cloud';
    Param.waveImage = pluginParams['WaveImage'] || 'KMS_wave';
    Param.waveOpacity = Number(pluginParams['WaveOpacity'] || 64);
    Param.speed = {
        x: Number(pluginParams['SpeedX'] || -1.0),
        y: Number(pluginParams['SpeedY'] ||  0.5)
    };
    Param.autoTone = Boolean(Number(pluginParams['AutoToneChange'] || 1));


    function KMS_WaterEffect() {
        this.initialize(...arguments);
    }

    KMS_WaterEffect.prototype.initialize = function() {
        this._speed = { x: Param.speed.x, y: Param.speed.y };
        this._colorFilter = new PIXI.filters.ColorMatrixFilter();
        
        if (Param.autoTone) {
            // PixiJS v5+ 用の 5x4 マトリクス
            this._colorFilter.matrix = [
                0.9, 0, 0, 0, 0,
                0, 0.9, 0, 0, 0,
                0.2, 0.2, 1, 0, 0,
                0, 0, 0, 1, 0
            ];
        }

        this._dispSprite = new Sprite();
        this._waveSprite = new TilingSprite();
        this._waveSprite.blendMode = PIXI.BLEND_MODES.ADD;
        this._waveSprite.opacity = Param.waveOpacity;
        this._waveSprite.scale.x = 1.0;
        this._waveSprite.scale.y = 1.0;

        const margin = 24;
        this._waveSprite.move(-margin, -margin, Graphics.width + margin, Graphics.height + margin);
    };

    /*
    * 画像のロード
    */
    KMS_WaterEffect.prototype.loadImage = function() {
        this._dispBitmap = ImageManager.loadBitmap(Param.imageDir, Param.dispImage);
        this._waveBitmap = ImageManager.loadBitmap(Param.imageDir, Param.waveImage);
    };

    /*
    * ロード完了判定
    */
    KMS_WaterEffect.prototype.isReady = function() {
        return this._dispBitmap.isReady() && this._waveBitmap.isReady();
    };

    /*
    * エフェクトの生成
    */
    KMS_WaterEffect.prototype.createEffect = function() {
        if (this._dispFilter) return;
        if (!this.isReady()) return;

        this._dispBitmap.baseTexture.wrapMode = PIXI.WRAP_MODES.REPEAT;
        this._dispSprite.bitmap = this._dispBitmap;
        this._dispSprite.scale.x = Graphics.width / Math.max(this._dispBitmap.width, 1);
        this._dispSprite.scale.y = Graphics.height / Math.max(this._dispBitmap.height, 1);
        
        this._dispFilter = new PIXI.filters.DisplacementFilter(this._dispSprite);

        this._waveSprite.bitmap = this._waveBitmap;
        this._waveSprite.filters = [this._dispFilter];
    };

    KMS_WaterEffect.prototype.update = function() {
        if (!this._dispFilter) {
            if (this.isReady()) {
                this.createEffect();
            } else {
                return;
            }
        }
        
        this._dispSprite.x += this._speed.x;
        this._dispSprite.y += this._speed.y;
        // TilingSprite のスクロールは origin から tilePosition に変更
        this._waveSprite.tilePosition.x += this._speed.x / 2.0;
        this._waveSprite.tilePosition.y += this._speed.y / 2.0;
    };

    Object.defineProperty(KMS_WaterEffect.prototype, 'filters', {
        get: function() {
            return Param.autoTone ?
                [this._dispFilter, this._colorFilter] :
                [this._dispFilter];
        }
    });

    Object.defineProperty(KMS_WaterEffect.prototype, 'dispSprite', {
        get: function() {
            return this._dispSprite;
        }
    });

    Object.defineProperty(KMS_WaterEffect.prototype, 'waveSprite', {
        get: function() {
            return this._waveSprite;
        }
    });


    Spriteset_Base.prototype.createWaterMapEffect = function() {
        if ($dataMap && $dataMap.meta.WaterEffect) {
            this._waterEffect = new KMS_WaterEffect();
            this._waterEffect.loadImage();
        }
    };

    Spriteset_Base.prototype.applyWaterMapEffectBody = function(target, waveContainer) {
        if (!this._waterEffect) {
            return;
        }

        this._waterEffect.createEffect();

        if (Array.isArray(target)) {
            for (let i = 0; i < target.length; ++i) {
                if (target[i]) {
                    target[i].filters = this._waterEffect.filters;

                    const margin = 48;
                    const width  = Graphics.width + margin;
                    const height = Graphics.height + margin;
                    target[i].filterArea = new Rectangle(-margin, -margin, width, height);
                }
            }
        }

        if (waveContainer) {
            waveContainer.addChild(this._waterEffect.dispSprite);
            waveContainer.addChild(this._waterEffect.waveSprite);
        }
    };

    Spriteset_Base.prototype.updateWaterMapEffect = function() {
        if (this._waterEffect) {
            this._waterEffect.update();
        }
    };

    const _KMS_WaterMapEffect_Spriteset_Base_update = Spriteset_Base.prototype.update;
    Spriteset_Base.prototype.update = function() {
        _KMS_WaterMapEffect_Spriteset_Base_update.apply(this, arguments)
        this.updateWaterMapEffect();
    };

    const _KMS_WaterMapEffect_Spriteset_Map_initialize = Spriteset_Map.prototype.initialize;
    Spriteset_Map.prototype.initialize = function() {
        _KMS_WaterMapEffect_Spriteset_Map_initialize.apply(this, arguments)
        this.createWaterMapEffect();
    };

    Spriteset_Map.prototype.applyWaterMapEffect = function() {
        this.applyWaterMapEffectBody([this], this._baseSprite);
    };


    const _KMS_WaterMapEffect_Spriteset_Battle_initialize = Spriteset_Battle.prototype.initialize;
    Spriteset_Battle.prototype.initialize = function() {
        _KMS_WaterMapEffect_Spriteset_Battle_initialize.apply(this, arguments)
        this.createWaterMapEffect();
    };

    Spriteset_Battle.prototype.applyWaterMapEffect = function() {
        this.applyWaterMapEffectBody([this._backgroundSprite, this._back1Sprite, this._back2Sprite], this._battleField);
    };


    const _KMS_WaterMapEffect_Scene_Map_start = Scene_Map.prototype.start;
    Scene_Map.prototype.start = function() {
        _KMS_WaterMapEffect_Scene_Map_start.apply(this, arguments)
        if (this._spriteset) {
            this._spriteset.applyWaterMapEffect();
        }
    };


    const _KMS_WaterMapEffect_Scene_Battle_start = Scene_Battle.prototype.start;
    Scene_Battle.prototype.start = function() {
        _KMS_WaterMapEffect_Scene_Battle_start.apply(this, arguments)
        if (this._spriteset) {
            this._spriteset.applyWaterMapEffect();
        }
    };

})();